import { createSlice, nanoid } from '@reduxjs/toolkit';

const initialState = [
  { id: '1', name: 'Samantha Doe', email: 'samantha@example.com', company: 'ABC Inc', phone: '123-456-7890' },
  { id: '2', name: 'John Smith', email: 'john@example.com', company: 'XYZ Corp', phone: '234-567-8901' },
  { id: '3', name: 'Jane Johnson', email: 'jane@example.com', company: 'Acme Ltd', phone: '345-678-9012' },
  { id: '4', name: 'Michael Brown', email: 'michael@example.com', company: 'Globex', phone: '456-789-0123' },
];

const contactsSlice = createSlice({
  name: 'contacts',
  initialState,
  reducers: {
    addContact: {
      reducer(state, action) {
        state.push(action.payload);
      },
      prepare(contact) {
        return { payload: { ...contact, id: nanoid() } };
      },
    },
    updateContact(state, action) {
      const index = state.findIndex(c => c.id === action.payload.id);
      if (index >= 0) {
        state[index] = action.payload;
      }
    },
    deleteContact(state, action) {
      return state.filter(c => c.id !== action.payload);
    },
  },
});

export const { addContact, updateContact, deleteContact } = contactsSlice.actions;
export default contactsSlice.reducer;
