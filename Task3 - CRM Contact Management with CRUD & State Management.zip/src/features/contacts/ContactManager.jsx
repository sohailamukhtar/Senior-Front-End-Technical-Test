import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addContact, updateContact, deleteContact } from './contactsSlice';
import './contactStyles.css';

const initialFormState = { name: '', email: '', company: '', phone: '' };

function ContactManager() {
  const contacts = useSelector(state => state.contacts);
  const dispatch = useDispatch();
  const [formData, setFormData] = useState(initialFormState);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    if (editingId) {
      dispatch(updateContact({ ...formData, id: editingId }));
    } else {
      dispatch(addContact(formData));
    }
    setFormData(initialFormState);
    setEditingId(null);
  };

  const handleEdit = contact => {
    setFormData(contact);
    setEditingId(contact.id);
  };

  const handleDelete = id => {
    dispatch(deleteContact(id));
  };

  const filteredContacts = contacts.filter(contact =>
    Object.values(contact).some(val =>
      val.toLowerCase().includes(search.toLowerCase())
    )
  );

  return (
    <div className="container">
      <h2>Contact Management</h2>
      <div className="header-row">
        <input
          type="text"
          placeholder="🔍 Search"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button onClick={() => setEditingId(null)}>+ Add Contact</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Company</th><th>Phone</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredContacts.map(c => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td>{c.email}</td>
              <td>{c.company}</td>
              <td>{c.phone}</td>
              <td>
                <button onClick={() => handleEdit(c)}>Edit</button>
                <button onClick={() => handleDelete(c.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <form onSubmit={handleSubmit} className="form">
        <h3>{editingId ? 'Edit Contact' : 'Add New Contact'}</h3>
        <input name="name" placeholder="Name" value={formData.name} onChange={handleChange} required />
        <input name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
        <input name="company" placeholder="Company" value={formData.company} onChange={handleChange} />
        <input name="phone" placeholder="Phone" value={formData.phone} onChange={handleChange} />
        <button type="submit">{editingId ? 'Update' : 'Add'}</button>
      </form>
    </div>
  );
}

export default ContactManager;
