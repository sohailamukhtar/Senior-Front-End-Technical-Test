import React from 'react';
import ContactManager from './features/contacts/ContactManager';

function App() {
  return (
    <div className="app">
      <ContactManager />
    </div>
  );
}

export default App;
