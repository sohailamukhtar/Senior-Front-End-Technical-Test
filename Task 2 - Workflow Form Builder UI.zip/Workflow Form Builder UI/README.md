# Workflow Form Builder UI

## Overview

This project is a dynamic workflow form builder interface built with React. It allows users to define custom workflow steps, each with multiple fields of various types (text, number, date, select). The app supports live preview, adding/removing steps and fields, and exporting the form configuration as JSON.

## Features

- Add/Edit/Remove workflow steps
- Each step supports multiple fields (text, number, date, select)
- Live preview of the form reflecting current configuration
- Export form configuration as JSON (copied to clipboard)
- Persist form configuration in localStorage between sessions

## Technology Stack

- React 18 with functional components
- React's `useReducer` for state management
- Plain CSS inline styling
- LocalStorage API for persistence

## Assumptions

- Only 4 field types are supported: text, number, date, and select.
- For select fields, options are simple comma-separated strings.
- No backend API integration; persistence uses browser localStorage.
- Drag-and-drop reorder is not implemented (optional bonus).
- UI focuses on functionality and usability, not heavy styling.

## Architecture Decisions

- Used `useReducer` for managing complex nested state of steps and fields to maintain immutable updates.
- State is initialized from localStorage to persist data.
- Components split into FormBuilder (for editing steps and fields), FieldEditor (for editing individual fields), and FormPreview (to show live preview).
- Export JSON feature copies the current config to clipboard for easy sharing.
- Simple component structure allows easy extensibility for drag-and-drop or API persistence.

## Setup Instructions

1. **Clone or download the repo**

```bash
git clone <repo-url>
cd workflow-form-builder
