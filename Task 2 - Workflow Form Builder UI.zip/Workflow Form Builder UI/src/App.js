import React, { useReducer, useEffect } from "react";
import FormBuilder from "./components/FormBuilder";
import FormPreview from "./components/FormPreview";
import { reducer, initialState } from "./reducer";

export default function App() {
  const [state, dispatch] = useReducer(reducer, initialState, (init) => {
    // Load from localStorage if available
    const stored = localStorage.getItem("workflowFormConfig");
    return stored ? JSON.parse(stored) : init;
  });

  // Persist state to localStorage on every change
  useEffect(() => {
    localStorage.setItem("workflowFormConfig", JSON.stringify(state));
  }, [state]);

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", fontFamily: "Arial, sans-serif" }}>
      <h1>Workflow Form Builder UI</h1>
      <div style={{ display: "flex", gap: 20 }}>
        <div style={{ flex: 1, border: "1px solid #ddd", padding: 10, borderRadius: 4 }}>
          <FormBuilder state={state} dispatch={dispatch} />
        </div>
        <div style={{ flex: 1, border: "1px solid #ddd", padding: 10, borderRadius: 4 }}>
          <FormPreview steps={state.steps} />
        </div>
      </div>
      <button
        onClick={() => {
          const json = JSON.stringify(state, null, 2);
          navigator.clipboard.writeText(json);
          alert("Form config JSON copied to clipboard!");
        }}
        style={{ marginTop: 20, padding: "8px 12px", cursor: "pointer" }}
      >
        Export JSON Config (copy to clipboard)
      </button>
    </div>
  );
}
