import React from "react";
import FieldEditor from "./FieldEditor";

export default function FormBuilder({ state, dispatch }) {
  const { steps } = state;

  return (
    <div>
      <h2>Form Builder</h2>
      <button
        onClick={() => dispatch({ type: "ADD_STEP" })}
        style={{ marginBottom: 10, padding: "6px 12px", cursor: "pointer" }}
      >
        + Add Step
      </button>

      {steps.length === 0 && <p>No steps yet. Add one!</p>}

      {steps.map((step) => (
        <div
          key={step.id}
          style={{
            marginBottom: 20,
            padding: 10,
            border: "1px solid #ccc",
            borderRadius: 4,
            background: "#fafafa",
          }}
        >
          <input
            type="text"
            value={step.name}
            onChange={(e) =>
              dispatch({
                type: "UPDATE_STEP_NAME",
                payload: { stepId: step.id, name: e.target.value },
              })
            }
            style={{ fontWeight: "bold", fontSize: 16, width: "100%", marginBottom: 8 }}
          />
          <button
            onClick={() => dispatch({ type: "REMOVE_STEP", payload: { stepId: step.id } })}
            style={{
              marginBottom: 8,
              backgroundColor: "#e74c3c",
              color: "white",
              border: "none",
              padding: "4px 8px",
              cursor: "pointer",
            }}
          >
            Remove Step
          </button>

          <div style={{ marginLeft: 10 }}>
            <h4>Fields</h4>
            {step.fields.length === 0 && <p>No fields yet.</p>}

            {step.fields.map((field) => (
              <FieldEditor
                key={field.id}
                stepId={step.id}
                field={field}
                dispatch={dispatch}
              />
            ))}

            <button
              onClick={() => dispatch({ type: "ADD_FIELD", payload: { stepId: step.id } })}
              style={{ marginTop: 6, cursor: "pointer" }}
            >
              + Add Field
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
