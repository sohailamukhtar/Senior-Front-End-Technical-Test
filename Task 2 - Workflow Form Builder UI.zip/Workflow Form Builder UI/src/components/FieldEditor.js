import React from "react";

export default function FieldEditor({ stepId, field, dispatch }) {
  const fieldTypes = ["text", "number", "date", "select"];

  // Handle changes in field properties
  const updateField = (updates) =>
    dispatch({
      type: "UPDATE_FIELD",
      payload: { stepId, fieldId: field.id, updates },
    });

  // Handle select options editing as comma-separated string
  const handleOptionsChange = (e) => {
    const options = e.target.value.split(",").map((o) => o.trim());
    updateField({ options });
  };

  return (
    <div
      style={{
        border: "1px solid #ddd",
        padding: 8,
        marginBottom: 8,
        borderRadius: 4,
        backgroundColor: "#fff",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <input
          type="text"
          value={field.label}
          onChange={(e) => updateField({ label: e.target.value })}
          placeholder="Field label"
          style={{ flex: 1, marginRight: 8 }}
        />

        <select
          value={field.type}
          onChange={(e) => updateField({ type: e.target.value })}
          style={{ width: 120, marginRight: 8 }}
        >
          {fieldTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>

        <button
          onClick={() => dispatch({ type: "REMOVE_FIELD", payload: { stepId, fieldId: field.id } })}
          style={{
            backgroundColor: "#e74c3c",
            color: "white",
            border: "none",
            cursor: "pointer",
            padding: "4px 8px",
          }}
        >
          Remove
        </button>
      </div>

      {field.type === "select" && (
        <input
          type="text"
          placeholder="Options (comma separated)"
          value={field.options ? field.options.join(", ") : ""}
          onChange={handleOptionsChange}
          style={{ marginTop: 6, width: "100%" }}
        />
      )}
    </div>
  );
}
