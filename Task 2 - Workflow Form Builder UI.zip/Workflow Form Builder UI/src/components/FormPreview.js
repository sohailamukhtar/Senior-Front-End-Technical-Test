import React from "react";

export default function FormPreview({ steps }) {
  return (
    <div>
      <h2>Live Form Preview</h2>
      {steps.length === 0 && <p>No steps configured.</p>}

      {steps.map((step) => (
        <fieldset
          key={step.id}
          style={{ marginBottom: 20, borderColor: "#aaa", padding: 10 }}
        >
          <legend style={{ fontWeight: "bold" }}>{step.name}</legend>

          {step.fields.length === 0 && <p>No fields.</p>}

          {step.fields.map((field) => {
            switch (field.type) {
              case "text":
                return (
                  <div key={field.id} style={{ marginBottom: 8 }}>
                    <label>
                      {field.label}
                      <input type="text" disabled style={{ marginLeft: 8 }} />
                    </label>
                  </div>
                );

              case "number":
                return (
                  <div key={field.id} style={{ marginBottom: 8 }}>
                    <label>
                      {field.label}
                      <input type="number" disabled style={{ marginLeft: 8 }} />
                    </label>
                  </div>
                );

              case "date":
                return (
                  <div key={field.id} style={{ marginBottom: 8 }}>
                    <label>
                      {field.label}
                      <input type="date" disabled style={{ marginLeft: 8 }} />
                    </label>
                  </div>
                );

              case "select":
                return (
                  <div key={field.id} style={{ marginBottom: 8 }}>
                    <label>
                      {field.label}
                      <select disabled style={{ marginLeft: 8 }}>
                        {field.options && field.options.length > 0 ? (
                          field.options.map((opt, i) => (
                            <option key={i} value={opt}>
                              {opt}
                            </option>
                          ))
                        ) : (
                          <option>No options</option>
                        )}
                      </select>
                    </label>
                  </div>
                );

              default:
                return null;
            }
          })}
        </fieldset>
      ))}
    </div>
  );
}
