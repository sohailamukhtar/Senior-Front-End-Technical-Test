export const initialState = {
  steps: [
    {
      id: 1,
      name: "Step 1",
      fields: [
        { id: 1, label: "Text Field", type: "text", value: "" }
      ],
    },
  ],
};

let nextStepId = 2;
let nextFieldId = 2;

export function reducer(state, action) {
  switch (action.type) {
    case "ADD_STEP":
      return {
        ...state,
        steps: [
          ...state.steps,
          { id: nextStepId++, name: `Step ${nextStepId - 1}`, fields: [] },
        ],
      };

    case "REMOVE_STEP":
      return {
        ...state,
        steps: state.steps.filter((step) => step.id !== action.payload.stepId),
      };

    case "UPDATE_STEP_NAME":
      return {
        ...state,
        steps: state.steps.map((step) =>
          step.id === action.payload.stepId
            ? { ...step, name: action.payload.name }
            : step
        ),
      };

    case "ADD_FIELD":
      return {
        ...state,
        steps: state.steps.map((step) =>
          step.id === action.payload.stepId
            ? {
                ...step,
                fields: [
                  ...step.fields,
                  {
                    id: nextFieldId++,
                    label: "New Field",
                    type: "text",
                    value: "",
                    options: [], // for select field
                  },
                ],
              }
            : step
        ),
      };

    case "REMOVE_FIELD":
      return {
        ...state,
        steps: state.steps.map((step) =>
          step.id === action.payload.stepId
            ? {
                ...step,
                fields: step.fields.filter((f) => f.id !== action.payload.fieldId),
              }
            : step
        ),
      };

    case "UPDATE_FIELD":
      return {
        ...state,
        steps: state.steps.map((step) =>
          step.id === action.payload.stepId
            ? {
                ...step,
                fields: step.fields.map((field) =>
                  field.id === action.payload.fieldId
                    ? { ...field, ...action.payload.updates }
                    : field
                ),
              }
            : step
        ),
      };

    case "REORDER_STEPS":
      return {
        ...state,
        steps: action.payload.steps,
      };

    default:
      return state;
  }
}
