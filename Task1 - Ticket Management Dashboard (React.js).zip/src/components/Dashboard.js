import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box, Select, MenuItem, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Paper, Typography,
  Pagination
} from '@mui/material';

const Dashboard = () => {
  const [tickets, setTickets] = useState([]);
  const [priorityFilter, setPriorityFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);

  const filteredTickets = tickets.filter(ticket =>
    (priorityFilter ? ticket.priority === priorityFilter : true) &&
    (statusFilter ? ticket.status === statusFilter : true)
  );

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(res => {
        const fakeTickets = res.data.slice(0, 30).map((t, index) => ({
          id: t.id,
          subject: t.title,
          priority: ['High', 'Medium', 'Low'][index % 3],
          status: ['Open', 'Closed'][index % 2],
          createdAt: new Date().toLocaleDateString()
        }));
        setTickets(fakeTickets);
      });
  }, []);

  const perPage = 10;
  const paginated = filteredTickets.slice((page - 1) * perPage, page * perPage);

  return (
    <Box p={4}>
      <Typography variant="h4" gutterBottom>Ticket Management Dashboard</Typography>

      <Box display="flex" gap={2} mb={2}>
        <Select value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)} displayEmpty>
          <MenuItem value="">All Priorities</MenuItem>
          <MenuItem value="High">High</MenuItem>
          <MenuItem value="Medium">Medium</MenuItem>
          <MenuItem value="Low">Low</MenuItem>
        </Select>

        <Select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} displayEmpty>
          <MenuItem value="">All Statuses</MenuItem>
          <MenuItem value="Open">Open</MenuItem>
          <MenuItem value="Closed">Closed</MenuItem>
        </Select>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Subject</TableCell>
              <TableCell>Priority</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Date Created</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginated.map(ticket => (
              <TableRow key={ticket.id}>
                <TableCell>{ticket.id}</TableCell>
                <TableCell>{ticket.subject}</TableCell>
                <TableCell>{ticket.priority}</TableCell>
                <TableCell>{ticket.status}</TableCell>
                <TableCell>{ticket.createdAt}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Box mt={2} display="flex" justifyContent="center">
        <Pagination
          count={Math.ceil(filteredTickets.length / perPage)}
          page={page}
          onChange={(e, val) => setPage(val)}
        />
      </Box>
    </Box>
  );
};

export default Dashboard;