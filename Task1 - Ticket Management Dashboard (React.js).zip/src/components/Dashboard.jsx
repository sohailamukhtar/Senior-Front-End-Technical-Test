import React, { useState, useEffect } from 'react'
import {
  Box, Typography, Table, TableHead, TableRow,
  TableCell, TableBody, Select, MenuItem, Modal, Pagination
} from '@mui/material'
import axios from 'axios'

const mockTickets = [
  { id: 1, subject: 'Cannot reset password', priority: 'High', status: 'Open', created: '2025-01-09' },
  { id: 2, subject: 'Error on checkout page', priority: 'Medium', status: 'Open', created: '2025-01-08' },
  { id: 3, subject: 'Feature request. Add dark mode', priority: 'Low', status: 'Open', created: '2025-01-01' },
  { id: 4, subject: 'Login button not working', priority: 'Medium', status: 'Closed', created: '2025-01-01' },
  { id: 5, subject: 'Performance improvement needed', priority: 'Medium', status: 'Open', created: '2025-01-02' },
  { id: 6, subject: 'Unable to access account', priority: 'High', status: 'Open', created: '2025-01-03' }
];

const Dashboard = () => {
  const [tickets, setTickets] = useState(mockTickets)
  const [priority, setPriority] = useState('')
  const [status, setStatus] = useState('')
  const [openModal, setOpenModal] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState(null)

  const filteredTickets = tickets.filter(t =>
    (!priority || t.priority === priority) &&
    (!status || t.status === status)
  );

  return (
    <Box p={4}>
      <Typography variant="h4" gutterBottom>Ticket Management Dashboard</Typography>
      <Box display="flex" gap={2} mb={2}>
        <Select value={priority} onChange={(e) => setPriority(e.target.value)} displayEmpty>
          <MenuItem value="">All Priorities</MenuItem>
          <MenuItem value="High">High</MenuItem>
          <MenuItem value="Medium">Medium</MenuItem>
          <MenuItem value="Low">Low</MenuItem>
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} displayEmpty>
          <MenuItem value="">All Statuses</MenuItem>
          <MenuItem value="Open">Open</MenuItem>
          <MenuItem value="Closed">Closed</MenuItem>
        </Select>
      </Box>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Ticket ID</TableCell>
            <TableCell>Subject</TableCell>
            <TableCell>Priority</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Date Created</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {filteredTickets.map(ticket => (
            <TableRow key={ticket.id} onClick={() => { setSelectedTicket(ticket); setOpenModal(true); }}>
              <TableCell>{ticket.id}</TableCell>
              <TableCell>{ticket.subject}</TableCell>
              <TableCell sx={{ color: ticket.priority === 'High' ? 'red' : ticket.priority === 'Medium' ? 'orange' : 'gray' }}>
                {ticket.priority}
              </TableCell>
              <TableCell>{ticket.status}</TableCell>
              <TableCell>{ticket.created}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Pagination count={1} page={1} />
      <Modal open={openModal} onClose={() => setOpenModal(false)}>
        <Box p={4} bgcolor="white" mx="auto" my="20%" width={400}>
          <Typography variant="h6">{selectedTicket?.subject}</Typography>
          <Typography>Priority: {selectedTicket?.priority}</Typography>
          <Typography>Status: {selectedTicket?.status}</Typography>
          <Typography>Created: {selectedTicket?.created}</Typography>
        </Box>
      </Modal>
    </Box>
  )
}

export default Dashboard